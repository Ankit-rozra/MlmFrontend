export const fetchDataSuccess = (data) => ({
  type: 'SELF_PURCHASE_DATA',
  payload: data,
});
