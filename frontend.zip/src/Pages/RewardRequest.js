import React from 'react';
import TopNav from './TopNav';
function RewardRequest() {
  return (
    <div>
      <TopNav display="Reward" />
    </div>
  );
}

export default RewardRequest;
