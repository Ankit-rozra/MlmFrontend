import React from 'react';
import TopNav from '../Pages/TopNav';
function OrderScreen() {
  return (
    <div>
      <TopNav display="Orders" />
    </div>
  );
}

export default OrderScreen;
