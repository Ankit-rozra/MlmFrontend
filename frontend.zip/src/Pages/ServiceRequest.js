import React from 'react';
import TopNav from './TopNav';
function ServiceRequest() {
  return (
    <div>
      <TopNav display="Service" />
    </div>
  );
}

export default ServiceRequest;
