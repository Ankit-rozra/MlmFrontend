import React, { useEffect } from 'react';
import TopNav from './TopNav';
import { useState } from 'react';
import Cookies from 'js-cookie';
import jwt_decode from 'jwt-decode';
import axios from 'axios';
import '../Css/Profile.css';

function Profile() {
  const [user, setUser] = useState(null);
  useEffect(() => {
    const fetchData = async () => {
      const token = Cookies.get('token');
      if (token) {
        const user = jwt_decode(token);
        const userId = user.userId;
        console.log(userId);

        try {
          const response = await axios.get(
            `http://localhost:5000/user/userInfo/${userId}`
          );
          setUser(response.data);
        } catch (error) {
          console.error(error);
        }
      }
    };
    fetchData(); // Call the async function to fetch data
  }, []);
  return (
    <div>
      {console.log(user)}
      <TopNav display="Profile" />
      {user !== null && (
        <div className="profile">
          {/* Your content goes here */}
          <p className="details">
            <p>Username : {user.username}</p>
          </p>
          <p>
            <p>Email : {user.email}</p>
          </p>
          <p>
            <p>Mobile : {user.mobile}</p>
          </p>
          <p>
            <p>Aadhaar : {user.adhaarNumber}</p>
          </p>
          <p>
            <p>Referral Code : {user.referralCode}</p>
          </p>
          <p>
            <p>Upi Id : {user.upi}</p>
          </p>
          <p>
            <p>Address : {user.address}</p>
          </p>
        </div>
      )}
      {user ===null && <div>Please Login 
      </div>}
    </div>
  );
}

export default Profile;

//
//
// "1234567890"
// answer
//
// "io"
// bp
//
// 0
// bv
//
// 0
// createdAt
//
// "2023-09-03T132559.266Z"
// directJoinningBonus
//
// 0
// email
//
// "ao@gmail.com"
// mobile
//
// "9876543210"
// pairEarning
//
// 0
// password
//
// "$2b$10$uYduEy.sVix5FEYfHRkG2.dkDRssOJ9jGTVKKECJV/BZD7oMMg.bC"
// prize
//
// null
// question
//
// "What is the name of your first pet?"
// recruits
//
// []
// referralCode
//
// "lhJ4EXmJ"
// searchCode
//
// "ABB"
// sponsor
//
// "64ea4e7fb1a01a5230cf11f2"
// subSponser
//
// "64f483e2a25693d6780fc9a7"
// topupAmount
//
// 1000
// upi
//
// "qq"
// username
//
// "kk"
