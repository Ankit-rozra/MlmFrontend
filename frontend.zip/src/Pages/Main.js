import React from 'react';
import '../Css/Main.css';
import VNavbar from './VNavbar';

import Page from './Page';
const Main = () => {
  return (
    <div>
      <Page />
    </div>
  );
};

export default Main;
