import React from 'react';
import TopNav from './TopNav';
function OrderRequest() {
  return (
    <div>
      <TopNav display="Order" />
    </div>
  );
}

export default OrderRequest;
