import React from 'react';
import TopNav from './TopNav';
function RegisterRequest() {
  return (
    <div>
      <TopNav display="Register" />
    </div>
  );
}

export default RegisterRequest;
