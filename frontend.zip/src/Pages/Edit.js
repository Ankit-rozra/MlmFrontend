import React from 'react';
import TopNav from './TopNav';
function Edit() {
  return (
    <div>
      <TopNav display="Edit" />
    </div>
  );
}

export default Edit;
