import React, { useEffect } from 'react';
import TopNav from './TopNav';
import { useState } from 'react';
import Cookies from 'js-cookie';
import jwt_decode from 'jwt-decode';
import axios from 'axios';
import '../Css/Profile.css';
function Network() {
  const [userDb, setUser] = useState(null);
  const [parent, setParent] = useState(null);

  const [filteredUser, setFilteredUser] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/user/alldata`);
        setUser(response.data);
        console.log(response.data);
      } catch (error) {
        console.error(error);
      }
    };
    fetchData(); // Call the async function to fetch data
  }, []);
  useEffect(() => {
    const token = Cookies.get('token');
    if (token && userDb !== null) {
      const user = jwt_decode(token);
      setParent(user);
      const userId = user.userId;
      // console.log(userId);

      const filteredData = userDb.filter(
        (item) => item.sponsor === userId || item.subSponser === userId
      );
      setFilteredUser(filteredData);
    }
  }, [userDb]);

  console.log('filter', filteredUser);

  return (
    <div>
      <TopNav display="Network" />
      {console.log('hj', filteredUser)}
      {filteredUser.map((user) => (
        <div className="profile">
          <div>{user.username}</div>
          <div>{user.referralCode}</div>
        </div>
      ))}{' '}
    </div>
  );
}

export default Network;
