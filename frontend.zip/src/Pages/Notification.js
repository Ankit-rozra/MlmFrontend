import React from 'react';
import TopNav from './TopNav';
function Notification() {
  return (
    <div>
      <TopNav display="Notification" />
    </div>
  );
}

export default Notification;
